import os
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_mysqldb import MySQL
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from dotenv import load_dotenv
from werkzeug.utils import secure_filename
import pandas as pd
import json
from datetime import datetime

load_dotenv()
app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'una-clave-secreta-muy-dificil-de-adivinar')

app.config['MYSQL_HOST'] = os.getenv('DB_HOST', 'localhost')
app.config['MYSQL_USER'] = os.getenv('DB_USER', 'ra_usuario')
app.config['MYSQL_PASSWORD'] = os.getenv('DB_PASSWORD', '666')
app.config['MYSQL_DB'] = os.getenv('DB_NAME', 'revista_academica')
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'

mysql = MySQL(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = "Por favor, inicie sesión para acceder a esta página."
login_manager.login_message_category = "warning"

class User(UserMixin):
    def __init__(self, id, nombre_usuario, roles):
        self.id = id
        self.nombre_usuario = nombre_usuario
        self.roles = roles.split(',') if roles else []


@login_manager.user_loader
def load_user(user_id):
    cur = mysql.connection.cursor()
    cur.callproc('usuarioRolID', [user_id])
    user_data = cur.fetchone()
    cur.close()
    
    if user_data:
        return User(id=user_data['id_usuario'], nombre_usuario=user_data['nombre_usuario'], roles=user_data['roles'])
    return None

@app.context_processor
def inject_now():
    return {'now': datetime.now()}

@app.route("/")
def inicio():
    return render_template('index.html')

@app.route('/registro', methods=['GET', 'POST'])
def registro():
    if request.method == 'POST':
        try:
            nombre_usuario = request.form['nombre_usuario']
            email = request.form['email']
            password = request.form['password']
            nombre = request.form['nombre']
            apellido_paterno = request.form['apellido_paterno']
            apellido_materno = request.form['apellido_materno']
            afiliacion = request.form.get('afiliacion', '')
            roles_a_asignar = 'AUTOR'

            cur = mysql.connection.cursor()
            args = [
                nombre_usuario, email, password,
                nombre, apellido_paterno, apellido_materno, afiliacion,
                roles_a_asignar,
                0 
            ]
            
            cur.callproc('sp_registrar_usuario', args)
            cur.execute("SELECT @_sp_registrar_usuario_8")
            result = cur.fetchone()
            id_usuario_nuevo = result['@_sp_registrar_usuario_8']

            mysql.connection.commit()
            cur.close()

            flash(f'¡Registro exitoso! Usuario "{nombre_usuario}" creado. Ahora puedes iniciar sesión.', 'success')
            return redirect(url_for('login'))

        except Exception as e:
            flash(f'Error en el registro: {e}', 'danger')
            return redirect(url_for('registro'))
    
    return render_template('registro.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        email_usuario = request.form['usuario_o_email']
        password = request.form['password']

        cur = mysql.connection.cursor()
        cur.callproc('loginUsuarioRol', [email_usuario, password])
        user_data = cur.fetchone()
        cur.close()

        if user_data and user_data.get('status') == 'OK':
            user_to_login = User(id=user_data['id_usuario'], nombre_usuario=user_data['nombre_usuario'], roles=user_data['roles'])
            login_user(user_to_login)
            session['roles'] = user_to_login.roles

            return redirect(url_for('dashboard'))
        else:
            flash('Usuario o contraseña incorrectos.', 'danger')
            return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    session.pop('roles', None)
    flash('Has cerrado sesión exitosamente.', 'success')
    return redirect(url_for('inicio'))

def obtener_articulos_no_revision(id_autor):
    cur = mysql.connection.cursor()
    cur.callproc('articulosPorAutor', [id_autor])
    articulos = cur.fetchall()
    cur.close()

    filtrados = [a for a in articulos if a['codigo_estado'] != 'en_revision']
    return filtrados

@app.route('/dashboard')
@login_required
def dashboard():
    id_autor = obtener_id_autor_de_usuario(current_user.id)

    articulos_filtrados = []
    if 'AUTOR' in current_user.roles and id_autor:
        articulos_filtrados = obtener_articulos_no_revision(id_autor)
    asignaciones_revisor = []
    if 'REVISOR' in current_user.roles:
        id_revisor = obtener_id_revisor_de_usuario(current_user.id)
        if id_revisor:
            cur = mysql.connection.cursor()
            cur.callproc('asignacionesPorRevisor', [id_revisor])
            asignaciones_revisor = cur.fetchall()
            cur.close()


    return render_template(
        'dashboard.html',
        articulos_no_revision=articulos_filtrados,
        asignaciones_revisor=asignaciones_revisor
    )

@app.route('/api/reporte/tiempos_por_etapa')
@login_required
def api_tiempos_etapa():
    if 'EDITOR_JEFE' not in current_user.roles:
        return jsonify({"error": "No autorizado"}), 403

    cur = mysql.connection.cursor()
    cur.callproc('tiemposPorEtapa', ['2020-01-01', '2025-12-31'])
    data = cur.fetchall()
    cur.close()

    df = pd.DataFrame(data)
    chart_data = {
        'labels': df['estado'].tolist(),
        'datasets': [{
            'label': 'Promedio de Días en Etapa',
            'data': df['dias_en_etapa'].tolist(),
            'backgroundColor': 'rgba(54, 162, 235, 0.5)'
        }]
    }
    return jsonify(chart_data)

@app.route('/auditoria/articulos')
@login_required
def auditoria_articulos():
    if 'EDITOR_JEFE' not in current_user.roles:
        flash('No tiene permisos para ver la auditoría.', 'danger')
        return redirect(url_for('dashboard'))
    try:
        cur = mysql.connection.cursor()
        cur.callproc('obtenerAuditoriaArticulos')
        registros = cur.fetchall()
        cur.close()

        return render_template('auditoria_articulos.html', registros=registros)
    except Exception as e:
        flash(f'Error al cargar la auditoría de artículos: {e}', 'danger')
        return redirect(url_for('dashboard'))

@app.route('/api/reporte/tasa_aceptacion')
@login_required
def api_tasa_aceptacion():
    if 'EDITOR_JEFE' not in current_user.roles:
        return jsonify({"error": "No autorizado"}), 403

    cur = mysql.connection.cursor()
    cur.callproc('tasaAceptacion', ['2020-11-01', '2025-12-31'])
    
    data = cur.fetchall()
    cur.close()

    df = pd.DataFrame(data)
    chart_data = {
        'labels': df['convocatoria'].tolist(),
        'datasets': [{
            'label': 'Tasa de Aceptación (%)',
            'data': df['tasa_aceptacion'].tolist(),
            'backgroundColor': 'rgba(75, 192, 192, 0.5)'
        }]
    }
    return jsonify(chart_data)

@app.route('/api/reporte/productividad_revisor')
@login_required
def api_productividad_revisor():
    if 'EDITOR_JEFE' not in current_user.roles:
        return jsonify({"error": "No autorizado"}), 403

    cur = mysql.connection.cursor()
    cur.callproc('productividadRevisor', ['2020-11-01', '2025-12-31'])
    cur.execute("SELECT * FROM tmpProductividad")
    data = cur.fetchall()
    cur.close()

    df = pd.DataFrame(data)
    chart_data = {
        'labels': df['revisor'].tolist(),
        'datasets': [{
            'label': 'Número de Dictámenes',
            'data': df['total_dictamenes'].tolist(),
            'backgroundColor': 'rgba(255, 206, 86, 0.5)'
        }]
    }
    return jsonify(chart_data)

@app.route('/api/reporte/envios_area')
@login_required
def api_envios_area():
    if 'EDITOR_JEFE' not in current_user.roles:
        return jsonify({"error": "No autorizado"}), 403

    cur = mysql.connection.cursor()
    cur.callproc('enviadosPorArea', ['2020-11-01', '2025-12-31'])
    
    data = cur.fetchall()
    cur.close()

    df = pd.DataFrame(data)
    colors = [
        'rgba(255, 99, 132, 0.5)', 'rgba(54, 162, 235, 0.5)',
        'rgba(255, 206, 86, 0.5)', 'rgba(75, 192, 192, 0.5)',
        'rgba(153, 102, 255, 0.5)'
    ]
    chart_data = {
        'labels': df['area'].tolist(),
        'datasets': [{
            'label': 'Artículos Enviados',
            'data': df['total_articulos'].tolist(),
            'backgroundColor': colors[:len(df)]
        }]
    }
    return jsonify(chart_data)

@app.route('/api/reporte/indice_numero/<int:id_numero>')
@login_required
def api_indice_numero(id_numero):
    if not any(r in current_user.roles for r in ['ADMIN', 'EDITOR_JEFE', 'EDITOR_ASOCIADO']):
        return jsonify({'error': 'No autorizado'}), 403

    try:
        cur = mysql.connection.cursor()
        cur.callproc('indiceNumero', [id_numero])
        data = cur.fetchall()
        cur.close()

        if not data:
            return jsonify({'numero_revista': 'Número no encontrado', 'articulos': []})

        df = pd.DataFrame(data)
        
        numero_nombre = df['numero_revista'].iloc[0]

        if pd.isna(df['articulo'].iloc[0]) or df['articulo'].iloc[0] == 'Sin artículos asignados':
             return jsonify({
                'numero_revista': numero_nombre,
                'articulos': []
            })

        df['titulo'] = df['articulo'] 
        articulos_lista = df[['titulo', 'autores', 'estado']].to_dict(orient='records')

        return jsonify({
            'numero_revista': numero_nombre,
            'articulos': articulos_lista
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/mis_articulos')
@login_required
def mis_articulos():
    if 'AUTOR' not in current_user.roles:
        flash('No tiene permisos para ver esta página.', 'danger')
        return redirect(url_for('dashboard'))

    try:
        id_autor = obtener_id_autor_de_usuario(current_user.id)
        if not id_autor:
            return render_template('mis_articulos.html', articulos=[])

        cur = mysql.connection.cursor()
        cur.callproc('articulosPorAutor', [id_autor])
        articulos = cur.fetchall()
        cur.close()

        return render_template('mis_articulos.html', articulos=articulos)
    except Exception as e:
        flash(f'Error al cargar tus artículos: {e}', 'danger')
        return redirect(url_for('dashboard'))

def obtener_id_revisor_de_usuario(user_id):
    cur = mysql.connection.cursor()
    cur.execute("CALL obtenerRevisorPorUsuario(%s)", (user_id,))
    resultado = cur.fetchone()
    cur.close()
    return resultado['id_revisor'] if resultado else None

def obtener_id_autor_de_usuario(user_id):
    cur = mysql.connection.cursor()
    cur.execute("CALL obtenerAutorPorUsuario(%s)", (user_id,))
    resultado = cur.fetchone()
    cur.close()
    return resultado['id_autor'] if resultado else None

@app.route('/articulo/nuevo', methods=['GET', 'POST'])
@login_required
def nuevo_articulo():
    if 'AUTOR' not in current_user.roles:
        flash('No tiene permisos para realizar esta acción.', 'danger')
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        try:
            titulo = request.form['titulo']
            resumen = request.form['resumen']
            palabras_clave = request.form.get('palabras_clave', '')
            comentario_autor = request.form.get('comentario_autor', '')
            id_convocatoria = int(request.form['id_convocatoria'])
            id_area = int(request.form['id_area'])
            archivo = request.files.get('archivo_articulo')

            if not archivo or archivo.filename == '':
                flash('El archivo del artículo es obligatorio.', 'danger')
                return redirect(request.url)

            upload_folder = os.path.join('static', 'uploads')
            os.makedirs(upload_folder, exist_ok=True)

            nombre_archivo_seguro = secure_filename(archivo.filename)
            ruta_guardado = os.path.join(upload_folder, nombre_archivo_seguro)
            archivo.save(ruta_guardado)

            id_autor_principal = obtener_id_autor_de_usuario(current_user.id)
            if not id_autor_principal:
                flash('No se encontró un perfil de autor asociado a su cuenta.', 'danger')
                return redirect(url_for('dashboard'))

            cur = mysql.connection.cursor()

            args = [
                titulo,
                resumen,
                palabras_clave,
                id_convocatoria,
                id_area,
                ruta_guardado,
                comentario_autor,
                id_autor_principal,
                current_user.id,
                'enviado',
                0
            ]
            cur.callproc('articuloEnviar', args)
            mysql.connection.commit()
            cur.close()

            flash(f'Artículo "{titulo}" enviado con éxito.', 'success')
            return redirect(url_for('mis_articulos'))

        except Exception as e:
            print("ERROR al enviar artículo:", repr(e))
            flash(f'Error al enviar el artículo: {e}', 'danger')
            return redirect(url_for('nuevo_articulo'))

    cur = mysql.connection.cursor()
    cur.callproc('convocatoriasActivas')
    convocatorias = cur.fetchall()
    cur.close()

    areas = [] 

    return render_template('nuevo_articulo.html', convocatorias=convocatorias, areas=areas)

@app.route('/api/convocatoria/<int:id_convocatoria>/areas')
@login_required
def api_areas_por_convocatoria(id_convocatoria):
    if 'AUTOR' not in current_user.roles and 'EDITOR_JEFE' not in current_user.roles:
        return jsonify({"error": "No autorizado"}), 403

    try:
        cur = mysql.connection.cursor()
        cur.callproc('areasPorConvocatoria', [id_convocatoria])
        areas = cur.fetchall()
        cur.close()

        data = [
            {"id_area": a['id_area'], "nombre": a['nombre']}
            for a in areas
        ]
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/articulo/<int:id_articulo>/versionar', methods=['GET', 'POST'])
@login_required
def subir_nueva_version(id_articulo):
    if 'AUTOR' not in current_user.roles:
        flash('No tiene permisos para realizar esta acción.', 'danger')
        return redirect(url_for('dashboard'))

    id_autor_actual = obtener_id_autor_de_usuario(current_user.id)

    cur = mysql.connection.cursor()
    cur.callproc('obtenerArticuloAutor', [id_articulo])
    articulo = cur.fetchone()
    cur.close()

    if not articulo or articulo['id_autor'] != id_autor_actual:
        flash('No tiene permiso para editar este artículo.', 'danger')
        return redirect(url_for('mis_articulos'))

    if request.method == 'POST':
        try:
            comentario_autor = request.form.get('comentario_autor', '')
            archivo = request.files['archivo_articulo']

            if not archivo or archivo.filename == '':
                flash('Debe seleccionar un archivo para la nueva versión.', 'danger')
                return redirect(url_for('subir_nueva_version', id_articulo=id_articulo))

            nombre_archivo_seguro = secure_filename(archivo.filename)
            ruta_guardado = os.path.join('static/uploads', nombre_archivo_seguro)
            archivo.save(ruta_guardado)

            cur = mysql.connection.cursor()
            codigo_estado_nuevo = 'en_revision'
            args = [
                id_articulo,
                ruta_guardado,
                comentario_autor,
                current_user.id,
                codigo_estado_nuevo,
                0
            ]
            cur.callproc('articuloVersionar', args)
            cur.execute("SELECT @_articuloVersionar_5")
            result = cur.fetchone()
            nueva_version = result['@_articuloVersionar_5']
            mysql.connection.commit()
            cur.close()
            flash(f'Nueva versión (v{nueva_version}) del artículo subida con éxito.', 'success')
            return redirect(url_for('mis_articulos'))

        except Exception as e:
            flash(f'Error al subir la nueva versión: {e}', 'danger')
            return redirect(url_for('subir_nueva_version', id_articulo=id_articulo))

    return render_template('subir_version.html', articulo=articulo)

@app.route('/editor/gestion_articulos')
@login_required
def gestion_articulos():
    if not any(r in current_user.roles for r in ['EDITOR_JEFE', 'EDITOR_ASOCIADO', 'ADMIN']):
        flash('No tiene permisos para gestionar artículos.', 'danger')
        return redirect(url_for('dashboard'))

    cur = mysql.connection.cursor()
    cur.callproc('articulosPendientesGestion')
    articulos = cur.fetchall()
    cur.close()

    return render_template('gestion_articulos.html', articulos=articulos)


@app.route('/editor/articulo/<int:id_articulo>/asignar', methods=['POST'])
@login_required
def asignar_revisores_accion(id_articulo):
    if 'EDITOR_JEFE' not in current_user.roles:
        flash('No tiene permisos para realizar esta acción.', 'danger')
        return redirect(url_for('dashboard'))

    try:
        num_revisores = 2
        dias_plazo = 30
        codigo_estado_asignacion = 'asignado'

        cur = mysql.connection.cursor()
        args = [
            id_articulo,
            num_revisores,
            codigo_estado_asignacion,
            current_user.id,
            dias_plazo
        ]
        cur.callproc('asignarRevisores', args)
        mysql.connection.commit()
        cur.close()

        flash(f'Se han asignado {num_revisores} revisores al artículo ID {id_articulo} exitosamente.', 'success')

    except Exception as e:
        flash(f'Error al asignar revisores: {e}', 'danger')

    return redirect(url_for('gestion_articulos'))

@app.route('/revisor/mis_asignaciones')
@login_required
def mis_asignaciones():
    if 'REVISOR' not in current_user.roles:
        flash('No tiene permisos para acceder a esta página.', 'danger')
        return redirect(url_for('dashboard'))

    try:
        id_revisor = obtener_id_revisor_de_usuario(current_user.id)
        if not id_revisor:
            return render_template('mis_asignaciones.html', asignaciones=[])

        cur = mysql.connection.cursor()
        cur.callproc('AsignacionesPorRevisor', [id_revisor])
        asignaciones = cur.fetchall()
        cur.close()

        return render_template('mis_asignaciones.html', asignaciones=asignaciones)
    except Exception as e:
        flash(f'Error al cargar tus asignaciones: {e}', 'danger')
        return redirect(url_for('dashboard'))

@app.route('/revisor/revision/<int:id_asignacion>', methods=['GET', 'POST'])
@login_required
def realizar_revision(id_asignacion):
    if 'REVISOR' not in current_user.roles:
        flash('No tiene permisos para esta acción.', 'danger')
        return redirect(url_for('dashboard'))

    id_revisor = obtener_id_revisor_de_usuario(current_user.id)
    if not id_revisor:
        flash('No se encontró un perfil de revisor asociado a su usuario.', 'danger')
        return redirect(url_for('dashboard'))

    cur = mysql.connection.cursor()
    cur.callproc('obtenerAsignacionPorID', [id_asignacion])
    asignacion = cur.fetchone()
    cur.close()

    if not asignacion or asignacion['id_revisor'] != id_revisor:
        flash('No tiene permiso para acceder a esta revisión.', 'danger')
        return redirect(url_for('mis_asignaciones'))

    if request.method == 'POST':
        decision_id = request.form.get('decision')
        comentarios_autor = request.form.get('comentarios_autor', '').strip()
        comentarios_editor = request.form.get('comentarios_editor', '').strip()

        if not decision_id:
            flash('Debe seleccionar una decisión para el dictamen.', 'danger')
            return redirect(url_for('realizar_revision', id_asignacion=id_asignacion))

        mapa_decisiones = {
            '1': 'aceptar',
            '2': 'aceptar_con_cambios',
            '3': 'rechazar',
        }
        codigo_decision = mapa_decisiones.get(decision_id)
        if not codigo_decision:
            flash('Decisión no válida.', 'danger')
            return redirect(url_for('realizar_revision', id_asignacion=id_asignacion))

        puntaje_global = 0

        cur = mysql.connection.cursor()
        try:
            cur.callproc('dictaminar', [
                id_asignacion,
                codigo_decision,
                comentarios_autor,
                comentarios_editor,
                puntaje_global,
                current_user.id
            ])

            mysql.connection.commit()
            flash('Dictamen enviado con éxito.', 'success')
            return redirect(url_for('mis_asignaciones'))

        except Exception as e:
            mysql.connection.rollback()
            flash(f'Error al registrar el dictamen: {e}', 'danger')
            return redirect(url_for('realizar_revision', id_asignacion=id_asignacion))
        finally:
            cur.close()

    try:
        cur = mysql.connection.cursor()
        cur.callproc('datosArticulo', [asignacion['id_articulo']])
        articulo_anonimizado = cur.fetchone()
        cur.close()

        if not articulo_anonimizado:
            flash('No se pudieron cargar los datos del artículo.', 'danger')
            return redirect(url_for('mis_asignaciones'))

        return render_template(
            'realizar_revision.html',
            articulo=articulo_anonimizado,
            id_asignacion=id_asignacion
        )
    except Exception as e:
        flash(f"Error al cargar la página de revisión: {e}", "danger")
        return redirect(url_for('mis_asignaciones'))

@app.route('/editor/auditoria')
@login_required
def auditoria():
    if 'EDITOR_JEFE' not in current_user.roles:
        flash('No tiene permisos para acceder a esta página.', 'danger')
        return redirect(url_for('dashboard'))
    try:
        fecha_desde = request.args.get('fecha_desde')
        fecha_hasta = request.args.get('fecha_hasta')

        cur = mysql.connection.cursor()
        cur.callproc('auditoriaEditorial', [fecha_desde, fecha_hasta])
        historial = cur.fetchall()
        cur.close()
        return render_template('auditoria.html', historial=historial)
    except Exception as e:
        flash(f'Error al generar el reporte de auditoría: {e}', 'danger')
        return redirect(url_for('dashboard'))
@app.route('/editor/estado_articulos')
@login_required
def estado_articulos():
    if 'EDITOR_JEFE' not in current_user.roles:
        flash('No tiene permisos para acceder a esta página.', 'danger')
        return redirect(url_for('dashboard'))
    try:
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM vArticulosPorEstado ORDER BY id_articulo DESC")

        articulos = cur.fetchall()
        cur.close()

        return render_template('estado_articulos.html', articulos=articulos)
    except Exception as e:
        flash(f'Error al cargar el estado de los artículos: {e}', 'danger')
        return redirect(url_for('dashboard'))
@app.route('/editor/productividad_revisores')
@login_required
def productividad_revisores():
    if 'EDITOR_JEFE' not in current_user.roles:
        flash('No tiene permisos para acceder a esta página.', 'danger')
        return redirect(url_for('dashboard'))
    try:
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM vProductividadRevisor")

        revisores = cur.fetchall()
        cur.close()

        datos_para_grafico_json = json.dumps(revisores, default=str)

        return render_template(
            'productividad_revisores.html',
            revisores=revisores,
            datos_json=datos_para_grafico_json
        )
    except Exception as e:
        flash(f'Error al cargar la productividad de revisores: {e}', 'danger')
        return redirect(url_for('dashboard'))
@app.route('/editor/tasa_aceptacion')
@login_required
def tasa_aceptacion_convocatoria():
    if 'EDITOR_JEFE' not in current_user.roles:
        flash('No tiene permisos para acceder a esta página.', 'danger')
        return redirect(url_for('dashboard'))
    try:
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM vAceptacionPorConvocatoria ORDER BY id_convocatoria DESC")
        convocatorias = cur.fetchall()
        cur.close()
        datos_para_grafico_json = json.dumps(convocatorias, default=str)

        return render_template(
            'tasa_aceptacion.html',
            convocatorias=convocatorias,
            datos_json=datos_para_grafico_json
        )
    except Exception as e:
        flash(f'Error al cargar la tasa de aceptación: {e}', 'danger')
        return redirect(url_for('dashboard'))
@app.route('/editor/envios_por_area')
@login_required
def envios_por_area():
    if 'EDITOR_JEFE' not in current_user.roles:
        flash('No tiene permisos para acceder a esta página.', 'danger')
        return redirect(url_for('dashboard'))
    try:
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM vEnviosPorArea")
        areas = cur.fetchall()
        cur.close()
        datos_para_grafico_json = json.dumps(areas, default=str)

        return render_template(
            'envios_por_area.html',
            areas=areas,
            datos_json=datos_para_grafico_json
        )
    except Exception as e:
        flash(f'Error al cargar el reporte de envíos por área: {e}', 'danger')
        return redirect(url_for('dashboard'))
@app.route('/editor/tiempos_por_etapa')
@login_required
def tiempos_por_etapa_vista():
    if 'EDITOR_JEFE' not in current_user.roles:
        flash('No tiene permisos para acceder a esta página.', 'danger')
        return redirect(url_for('dashboard'))
    try:
        cur = mysql.connection.cursor()

        cur.execute("SELECT * FROM vTiemposPorEtapa")

        etapas = cur.fetchall()
        cur.close()
        datos_para_grafico_json = json.dumps(etapas, default=str)

        return render_template(
            'tiempos_etapa.html',
            etapas=etapas,
            datos_json=datos_para_grafico_json
        )
    except Exception as e:
        flash(f'Error al cargar los tiempos por etapa: {e}', 'danger')
        return redirect(url_for('dashboard'))

@app.route('/editor/historial_autor')
@login_required
def historial_autor():
    if 'EDITOR_JEFE' not in current_user.roles:
        flash('No tiene permisos para acceder a esta página.', 'danger')
        return redirect(url_for('dashboard'))
    try:
        query = request.args.get('q', '')
        
        publicaciones = []
        autor_buscado = None
        if query:
            cur = mysql.connection.cursor()
            sql_query = "SELECT * FROM vHistorialPublicacionesAutor WHERE autor LIKE %s"
            cur.execute(sql_query, [f"%{query}%"])
            
            publicaciones = cur.fetchall()
            cur.close()
            if publicaciones:
                autor_buscado = publicaciones[0]['autor']
        return render_template(
            'historial_autor.html',
            publicaciones=publicaciones,
            autor_buscado=autor_buscado
        )
    except Exception as e:
        flash(f'Error al buscar el historial del autor: {e}', 'danger')
        return redirect(url_for('dashboard'))
@app.route('/editor/carga_revisores')
@login_required
def carga_revisores():
    if 'EDITOR_JEFE' not in current_user.roles:
        flash('No tiene permisos para acceder a esta página.', 'danger')
        return redirect(url_for('dashboard'))
    try:
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM vCargaRevisores")
        revisores = cur.fetchall()
        cur.close()
        return render_template('carga_revisores.html', revisores=revisores)
    except Exception as e:
        flash(f'Error al cargar la carga de revisores: {e}', 'danger')
        return redirect(url_for('dashboard'))


@app.route('/editor/articulo/<int:id_articulo>/detalles')
@login_required
def detalle_articulo_editor(id_articulo):
    if 'EDITOR_JEFE' not in current_user.roles:
        flash('No tiene permisos para esta acción.', 'danger')
        return redirect(url_for('dashboard'))

    try:
        cur = mysql.connection.cursor()
        cur.callproc('datosArticulo', [id_articulo])
        articulo = cur.fetchone()
        cur.close()

        if not articulo:
            flash('Artículo no encontrado.', 'danger')
            return redirect(url_for('gestion_articulos'))

        cur = mysql.connection.cursor()
        cur.callproc('asignacionesArticulo', [id_articulo])
        asignaciones = cur.fetchall()
        cur.close()

        cur = mysql.connection.cursor()
        cur.callproc('disponibilidadRevision', [id_articulo])
        revisores_disponibles = cur.fetchall()
        cur.close()

        return render_template(
            'detalle_articulo_editor.html',
            articulo=articulo,
            asignaciones=asignaciones,
            revisores_disponibles=revisores_disponibles
        )
    except Exception as e:
        flash(f'Error al cargar los detalles del artículo: {e}', 'danger')
        return redirect(url_for('gestion_articulos'))


@app.route('/editor/articulo/<int:id_articulo>/reasignar', methods=['POST'])
@login_required
def reasignar_revisor_accion(id_articulo):
    if 'EDITOR_JEFE' not in current_user.roles:
        flash('No tiene permisos para esta acción.', 'danger')
        return redirect(url_for('dashboard'))

    try:
        id_revisor_nuevo = request.form.get('id_revisor_nuevo')
        
        cur = mysql.connection.cursor()
        args = [
            id_articulo,
            id_revisor_nuevo,
            current_user.id
        ]
        cur.callproc('revisorReasignar', args)
        mysql.connection.commit()
        cur.close()

        flash('Revisor reasignado con éxito.', 'success')
    
    except Exception as e:
        flash(f'Error al reasignar el revisor: {e}', 'danger')

    return redirect(url_for('detalle_articulo_editor', id_articulo=id_articulo))

@app.route('/editor/publicacion', methods=['GET', 'POST'])
@login_required
def publicacion():
    if 'EDITOR_JEFE' not in current_user.roles:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('dashboard'))

    cur = mysql.connection.cursor()
    if request.method == 'POST':
        accion = request.form.get('accion')

        try:
            if accion == 'crear_numero':
                anio = request.form['anio']
                volumen = request.form['volumen']
                numero = request.form['numero']
                id_conv = request.form['id_convocatoria']
                fecha = request.form['fecha_publicacion']
                
                cur.callproc('crearNumeroRevista', [anio, volumen, numero, id_conv, fecha])
                mysql.connection.commit()
                flash(f'Número de revista creado exitosamente.', 'success')

            elif accion == 'publicar_articulo':
                id_articulo = request.form['id_articulo']
                id_numero = request.form['id_numero']
                
                cur.callproc('publicarArticulo', [id_articulo, id_numero, current_user.id])
                mysql.connection.commit()
                flash(f'¡Artículo #{id_articulo} publicado correctamente!', 'success')

        except Exception as e:
            mysql.connection.rollback()
            flash(f'Error en la operación: {e}', 'danger')
        
        return redirect(url_for('publicacion'))

    cur.execute("SELECT * FROM vArticulosParaPublicar")
    articulos_aceptados = cur.fetchall()
    cur.callproc('obtenerNumerosRevista')
    numeros_revista = cur.fetchall()
    cur.callproc('convocatoriasActivas')
    convocatorias = cur.fetchall()

    cur.close()

    return render_template(
        'publicacion.html',
        articulos=articulos_aceptados,
        numeros=numeros_revista,
        convocatorias=convocatorias
    )

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
